﻿using System;

namespace introToSE1.PersistantLayer

{
    public class IMessage
    {
        
        public IMessage(String g, string user, DateTime date, String body, String GroupId)
        {
            guid = g;
            UserName = user;
            Date = date;
            MessageContent = body;
            GroupID = GroupId;
        }
       public String guid { get; set; }
       public string UserName { get; set; }
       public DateTime Date { get; set; }
       public string MessageContent { get; set; }
       public string GroupID { get; set; }
      //  string ToString();
    }
}