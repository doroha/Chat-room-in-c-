﻿using introToSE1.PersistantLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace introToSE1
{
    //TRY CATCH SOMEWHERE OR EVERYWHERE 
    class Handler
    {
        

        public Handler()
        {
            
        }

        //add password
        public Boolean Resgister(String g_id, String nickname, String password)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            Boolean canRegister = Login(g_id, nickname, password);
            if (canRegister)
            {
                //already a user in DB who has those exact g_id nickname and password, notify to try again
                return false;
            }
            command.CommandText =
                "INSERT INTO Users ([Group_Id],[Nickname],[Password]) " +
                "VALUES (@group_id, @nickname, @password)";
            SqlParameter group_id_param = new SqlParameter(@"group_id", SqlDbType.Int, 20);//now sure if need to be int or text
            SqlParameter nickname_param = new SqlParameter(@"nickname", SqlDbType.Char, 8);
            SqlParameter password_param = new SqlParameter(@"password", SqlDbType.Char, 64);


            group_id_param.Value = Int32.Parse(g_id);
            nickname_param.Value = nickname;
            password_param.Value = password;

            command.Parameters.Add(group_id_param);
            command.Parameters.Add(nickname_param);
            command.Parameters.Add(password_param);
            command.Prepare();
            int num_rows_changed = command.ExecuteNonQuery();
            command.Dispose();
            connection.Close(); 
            return num_rows_changed == 1;
        }


        //wrote login as boolean will give chatroom boolean answer for if user exsits
        //addpassword
        public Boolean Login(String g_id, String nickname, String password)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            
            command.CommandText =
                "SELECT COUNT(*) FROM Users WHERE Group_Id = @group_id AND Nickname = @nickname AND Password = @password";
            SqlParameter group_id_param = new SqlParameter(@"group_id", SqlDbType.Int, 20);
            SqlParameter nickname_param = new SqlParameter(@"nickname", SqlDbType.Char, 8);
            SqlParameter password_param = new SqlParameter(@"password", SqlDbType.Char, 64);


            group_id_param.Value = Int32.Parse(g_id);
            nickname_param.Value = nickname;
           password_param.Value = password;

            command.Parameters.Add(group_id_param);
            command.Parameters.Add(nickname_param);
           command.Parameters.Add(password_param);
            command.Prepare();
            if ((int)command.ExecuteScalar() > 0)
            {
                command.Dispose();
                connection.Close();
                return true;
            }
            else
            {
                command.Dispose();
                connection.Close();
                return false;
            }
            
        }

        public List<IMessage> FilterByUser(String nickname, String g_id)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            List<IMessage> messages = new List<IMessage>();

            /* int id = getUserId(nickname, g_id);
             command.CommandText =
                 "SELECT * FROM Messages WHERE User_Id = @user_id";
             SqlParameter user_id_param = new SqlParameter(@"user_id", SqlDbType.Int, 20);
             user_id_param.Value = id;
             command.Parameters.Add(user_id_param);
             command.Prepare();
             SqlDataReader data_reader = command.ExecuteReader();
             while (data_reader.Read())
             {
                 DateTime datefacturation = new DateTime();
                 //if (!data_reader.IsDBNull(2))
                 //{
                     datefacturation = data_reader.GetDateTime(2);
                 //}
                 String[] info = getUserInfo(data_reader.GetInt32(1));
                 if (info != null)
                 {
                     messages.Add(new IMessage(data_reader.GetString(0), info[1], datefacturation, data_reader.GetString(3), info[0]));
                 }

             }*/
            command.CommandText =
                 "SELECT * FROM Messages " +
                "INNER JOIN Users ON Messages.User_Id = Users.Id "+
                "WHERE Group_Id = @group_id AND Nickname = @nickname";
            SqlParameter group_id_param = new SqlParameter(@"group_id", SqlDbType.Int, 20);
            SqlParameter nickname_param = new SqlParameter(@"nickname", SqlDbType.Char, 8);
            group_id_param.Value = Int32.Parse(g_id);
            nickname_param.Value = nickname;
            command.Parameters.Add(group_id_param);
            command.Parameters.Add(nickname_param);
            command.Prepare();
            SqlDataReader data_reader = command.ExecuteReader();
            while (data_reader.Read())
            {
                DateTime datefacturation = new DateTime();
                if (!data_reader.IsDBNull(2))
                {
                    datefacturation = data_reader.GetDateTime(2);
                }

                messages.Add(new IMessage(data_reader.GetString(0), data_reader.GetString(6), datefacturation, data_reader.GetString(3), data_reader.GetInt32(5).ToString()));

            }
            data_reader.Close();
            command.Dispose();
            connection.Close();
            return messages;
        }
        public List<IMessage> FilterByGroupId(string group_id)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            command.Parameters.Clear();
            List<IMessage> m = new List<IMessage>();
            command.CommandText =
                "SELECT * FROM Messages " +
               "INNER JOIN Users ON Messages.User_Id = Users.Id " +
               "WHERE Group_Id = @group_id";
            SqlParameter group_id_param = new SqlParameter(@"group_id", SqlDbType.Int, 20);
            group_id_param.Value = Int32.Parse(group_id);
            command.Parameters.Add(group_id_param);
            command.Prepare();
            SqlDataReader data_reader = command.ExecuteReader();
            while (data_reader.Read())
            {
                DateTime datefacturation = new DateTime();
                if (!data_reader.IsDBNull(2))
                {
                    datefacturation = data_reader.GetDateTime(2);
                }

                m.Add(new IMessage(data_reader.GetString(0), data_reader.GetString(6), datefacturation, data_reader.GetString(3), data_reader.GetInt32(5).ToString()));

            }
            data_reader.Close();
            command.Dispose();
            connection.Close();
            return m;
        }
        //check to see what paramater the send time is saved in sql table
        //this function retreives last messages for every two seconds
        public List<IMessage> RetreiveLast(DateTime Time)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            command.Parameters.Clear();
            List<IMessage> m = new List<IMessage>();
            command.CommandText =
                "SELECT * FROM Messages "+
                "INNER JOIN Users ON Messages.User_Id = Users.Id "+
                "WHERE SendTime >= @lastTime";
            SqlParameter last_time_param = new SqlParameter(@"lastTime", SqlDbType.DateTime, 64);
            last_time_param.Value = Time.ToUniversalTime();
            command.Parameters.Add(last_time_param);
            command.Prepare();
            SqlDataReader data_reader = command.ExecuteReader();
            while (data_reader.Read())
            {
                DateTime datefacturation = new DateTime();
                if (!data_reader.IsDBNull(2))
                {
                    datefacturation = data_reader.GetDateTime(2);
                }

                m.Add(new IMessage(data_reader.GetString(0), data_reader.GetString(6), datefacturation, data_reader.GetString(3), data_reader.GetInt32(5).ToString()));

            }
            data_reader.Close();
            command.Dispose();
            connection.Close();
            return m;
        }
        //this function retreives messages for new logins 
        public List<IMessage> RetreiveLastTwoHundred()
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            command.Parameters.Clear();
            List<IMessage> messages = new List<IMessage>();
            command.CommandText =
                "SELECT TOP(200)* FROM Messages "+
                "INNER JOIN Users ON Messages.User_Id=Users.Id";
            SqlDataReader data_reader = command.ExecuteReader();
            while (data_reader.Read())
            {
                DateTime datefacturation = new DateTime();
                if (!data_reader.IsDBNull(2))
                {
                    datefacturation = data_reader.GetDateTime(2);
                }
                
                messages.Add(new IMessage(data_reader.GetString(0), data_reader.GetString(6), datefacturation, data_reader.GetString(3), data_reader.GetInt32(5).ToString()));

            }
            data_reader.Close();
            command.Dispose();
            connection.Close();
            return messages;
        }

        //returns true if message was editted
        public Boolean editMessage(String g, String newBody)
        {
            Boolean changed = false;
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            command.Parameters.Clear();
            command.CommandText =
                "UPDATE Messages SET Body = @newBody WHERE Guid = @guid";
            SqlParameter guid_param = new SqlParameter(@"guid", SqlDbType.Char, 68);
            SqlParameter new_body_param = new SqlParameter(@"newBody", SqlDbType.NChar, 100);
            guid_param.Value = g;
            new_body_param.Value = newBody;
            command.Parameters.Add(guid_param);
            command.Parameters.Add(new_body_param);
            command.Prepare();
            int i = command.ExecuteNonQuery();
            connection.Close();
            SqlConnection connection1 = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection1.Open();
            SqlCommand command1 = new SqlCommand(null, connection1);
            command1.Parameters.Clear();
            command1.CommandText =
                "UPDATE Messages SET SendTime = @now WHERE Guid = @guid";
            SqlParameter guid1_param = new SqlParameter(@"guid", SqlDbType.Char, 68);
            SqlParameter now_param = new SqlParameter(@"now", SqlDbType.DateTime, 64);
            guid1_param.Value = g;
            now_param.Value = DateTime.Now.ToUniversalTime();
            command1.Parameters.Add(guid1_param);
            command1.Parameters.Add(now_param);
            command1.Prepare();
            int j = command1.ExecuteNonQuery();
            if(i ==1 & j == 1)
            {
                changed = true;
            }
            connection1.Close();
            return changed;
        }
        public Boolean Send(String body, String g_id, String nickname)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            SqlCommand command = new SqlCommand(null, connection);
            connection.Open();
            int id = getUserId(nickname, g_id);
            if (id == -1)
            {
                return false;
            }
            command.CommandText =
                "INSERT INTO Messages ([Guid],[User_Id],[SendTime],[Body]) " +
                "VALUES (@guid, @user_id, @sendTime,@body)";
            SqlParameter guid_param = new SqlParameter(@"guid", SqlDbType.Char, 68);
            SqlParameter user_id_param = new SqlParameter(@"user_id", SqlDbType.Int, 20);//now sure if need to be int or text
            SqlParameter SendTime_param = new SqlParameter(@"sendTime", SqlDbType.DateTime, 64);
            SqlParameter Body_param = new SqlParameter(@"body", SqlDbType.NChar, 100);
            Guid g = Guid.NewGuid();
            guid_param.Value = g.ToString();
            user_id_param.Value = id;
            SendTime_param.Value = DateTime.Now.ToUniversalTime();
            Body_param.Value = body;
            command.Parameters.Add(guid_param);
            command.Parameters.Add(user_id_param);
            command.Parameters.Add(SendTime_param);
            command.Parameters.Add(Body_param);
            command.Prepare();
            int i = command.ExecuteNonQuery();
            connection.Close();
            
            return i == 1;
        }
        public int getUserId(String nickname, String g_id)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            command.Parameters.Clear();
            command.CommandText =
               "SELECT * FROM Users WHERE Group_Id = @group_id AND Nickname = @nickname";
            SqlParameter group_id_param = new SqlParameter(@"group_id", SqlDbType.Int, 20);
            SqlParameter nickname_param = new SqlParameter(@"nickname", SqlDbType.Char, 64);
            group_id_param.Value = g_id;
            nickname_param.Value = nickname;
            command.Parameters.Add(group_id_param);
            command.Parameters.Add(nickname_param);
            command.Prepare();
            SqlDataReader reader = command.ExecuteReader();
            int id = -1;
            if (reader.Read())
                id = reader.GetInt32(0);
            connection.Close();
            return id;
        }
        public String[] getUserInfo(int i)
        {
            SqlConnection connection = new SqlConnection($"Data Source={"ise172.ise.bgu.ac.il,1433\\DB_LAB"};Initial Catalog={"MS3"};User ID={"publicUser"};Password={"isANerd"}");
            connection.Open();
            SqlCommand command = new SqlCommand(null, connection);
            command.Parameters.Clear();
            command.CommandText =
               "SELECT * FROM Users WHERE Id = @id";
            SqlParameter id_param = new SqlParameter(@"id", SqlDbType.Int, 20);
            id_param.Value = i;

            command.Parameters.Add(id_param);
            command.Prepare();
            SqlDataReader data_reader = command.ExecuteReader();
            String[] info = new String[2];
            while (data_reader.Read())
            {
                info[0] = data_reader.GetInt32(1).ToString();
                info[1] = data_reader.GetString(2);
            }
            data_reader.Close();
            connection.Close();
            return info;
        }
    }
}

//make new message? how does the message get printed out on screen in gui need to check with noa
/*
 * var query = from person in people
    join pet in pets on person equals pet.Owner
    select new { OwnerName = person.FirstName, PetName = pet.Name };

foreach (var ownerAndPet in query)
{
Console.WriteLine($"\"{ownerAndPet.PetName}\" is owned by {ownerAndPet.OwnerName}");
}
  */
