﻿using System;
using System.Collections.Generic;
using System.Linq;
using introToSE.LogicLayer;
using System.Collections.ObjectModel;
using System.Windows;
using System.ComponentModel;
using System.Collections.Specialized;
using System.Runtime.CompilerServices;
using introToSE1;
using introToSE1.PersistantLayer;

namespace introToSE.LogicLayer
{
    public class Chatroom 
    {
        private User LoggedinUser;
        private List<Message> messages; //= new List<Message>();
        private List<User> users = new List<User>();
        private List<Message> FilterMessages = new List<Message>();
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private DateTime retreiveTime= DateTime.Now;
        private static Handler handler;
        // private Boolean shown = false;
        private List<Message> SortedM;
        private List<Message> SortedMFilter;

        public Chatroom()
        {
            handler = new Handler();
            messages = new List<Message>();
        }
        public void Send(String body)
        {
            if (LoggedinUser != null)
            {
                if (handler.Send(body, LoggedinUser.getGroupID(), LoggedinUser.getNick()))
                    log.Info("new message sent");
            }
        }
        
        public Boolean MessageFromUser(Message mess)
        {
            if (mess.GetUserGroupID().Equals(LoggedinUser.getGroupID()))
            {
                if (mess.GetUserName().Equals(LoggedinUser.getNick()))
                {
                    return true;
                }
            }
            return false;
        }

        public Boolean EditMessage(Message message, String NewBody)
        {
            Boolean isAble = message.CanEdit(NewBody);
            if (isAble)
            {
                isAble = handler.editMessage(message.GetGuid(), NewBody);
            }
            return isAble;
        }
        
        public void SetUser(String GroupID, String UserName, String Password)
        {
            try
            {
                
                    this.LoggedinUser = new User(UserName, GroupID, Password);
                
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
            }
           
            
        }
        public Boolean IsValidNickname(string g_id, string nick)
        {
            Boolean isValid = handler.getUserId(nick, g_id) < 0;
            if (!isValid)
            {
                MessageBox.Show("Nickname is already in use");
            }
           
            return isValid;
        }
        public Boolean isValidGroupID(string g_id)
        {
            Boolean isValid = false;
            try
            {
                if (g_id.All(char.IsDigit))
                {
                    isValid = true;
                }
                return isValid;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            return isValid;
        }
        public Boolean AvailableNickname(string g_id, string nick)
        {
            Boolean valid = false;
            valid = IsValidNickname(g_id, nick);
            return valid;
        }
        public bool Login(string GroupID, string UserName, String Password)
        {
            bool IsLogedIn = false;
            try
            {
                /*if(isValidGroupID(GroupID) & IsValidNickname(GroupID, UserName))
                {
                    SetUser(GroupID, UserName);
                    IsLogedIn = true;
                    log.Info("New User conected");
                    RetreiveLastTwoHundred();
                    retreiveTime = DateTime.Now;
                }*/
                IsLogedIn = handler.Login(GroupID, UserName, Password);
                if (IsLogedIn)
                {
                    log.Info("New User conected");
                    int i = handler.getUserId(UserName, GroupID);
                    String[] MeUser = handler.getUserInfo(i);
                    RetreiveLastTwoHundred();
                    retreiveTime = DateTime.Now;
                    SetUser(MeUser[0], MeUser[1], "");
                }
            }
            catch(Exception r)
            {
                MessageBox.Show(r.ToString());
            }
            return IsLogedIn;
            
            
        }

        private List<Message> RetreiveLastTwoHundred()
        {
            //find out how to make list form handler to give to chatroom

            List<IMessage> ToAddMess = new List<IMessage>();
            ToAddMess = handler.RetreiveLastTwoHundred();
            retreiveTime = DateTime.Now;
            foreach (IMessage m in ToAddMess)
            { 
                Message NewMess = new Message(m);
                messages.Add(NewMess);
            }
            SortByDateTime(true);
            return SortedM;
        }
        public List<Message> RetreiveLast(int sorter, bool Ascending)
        {
            List<IMessage> handled = new List<IMessage>();
            handled = handler.RetreiveLast(retreiveTime);
            retreiveTime = DateTime.Now;
            List<Message> ToAddMess = new List<Message>();
            try
            {
                foreach (IMessage m in handled)
                {
                        Message NewMess = new Message(m);
                        ToAddMess.Add(NewMess);
                }
                foreach (Message m in ToAddMess)
                {
                    
                   if (!MessagesContains(m))
                    {
                        messages.Add(m);
                    }
                    if (FilterMessages.Count() > 0)
                    {
                        if (m.GetUserGIDNumber() == FilterMessages[0].GetUserGIDNumber())
                        {
                            if (m.GetUserName().Equals(FilterMessages[0].GetUserName()))
                            {
                                if (!FilterMessagesContains(m))
                                {
                                    FilterMessages.Add(m);
                                }
                            }
                        }
                    }
                }
         
                switch (sorter)
                {
                    case 0:
                        SortByDateTime(Ascending);
                        break;
                    case 1:
                        SortByGroupID(Ascending);
                        break;
                    case 2:
                        SortByUserName(Ascending);
                        break;
                    case 3:
                        SortByAll(Ascending);
                        break;
                }
            }
            
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return SortedM;
        }
        
        public List<Message> DisplayAll(String GroupID, String UserName, Boolean Ascending)
        {
            Boolean stam = false;
            if (FilterMessages.Count() > 0)
            {
                if (GroupID.Equals(FilterMessages[0].GetUserGroupID()))
                {
                    if (UserName.Equals(FilterMessages[0].GetUserName().TrimEnd()))
                    {
                        SortFiltered(Ascending);
                        stam = true;
                    
                    }
                }
            }
            
                if (!stam)
                {
                    FilterMessages.Clear();
                    List<IMessage> filtered = handler.FilterByUser(UserName, GroupID);

                    foreach (IMessage m in filtered)
                    {
                        Message mess = new Message(m);
                        FilterMessages.Add(mess);
                    }
                    if (FilterMessages.Count > 0)
                    {
                        SortFiltered(Ascending);
                    }
                }
                
            
           
            return SortedMFilter;
        }
        public List<Message> DisplayAllFilterGroupID(String GroupID, Boolean Ascending, int sortBy)
        {
            Boolean stam = false;
            if (FilterMessages.Count() > 0)
            {
                if (GroupID.Equals(FilterMessages[0].GetUserGroupID()))
                {
                    if (sortBy == 2)
                    {
                        SortFilteredUser(Ascending);
                    }
                    else if (sortBy == 3)
                    {
                        SortFilteredAll(Ascending);
                    }
                    else
                        SortFiltered(Ascending);
                    stam = true;
                }
            }

            if (!stam)
            {
                FilterMessages.Clear();
                List<IMessage> filtered = handler.FilterByGroupId(GroupID);

                foreach (IMessage m in filtered)
                {
                    Message mess = new Message(m);
                    FilterMessages.Add(mess);
                }
                if (FilterMessages.Count > 0)
                {

                    if (sortBy == 2)
                    {
                        SortFilteredUser(Ascending);
                    }
                    else if (sortBy == 3)
                    {
                        SortFilteredAll(Ascending);
                    }
                    else
                        SortFiltered(Ascending);
                }
            }
            return SortedMFilter;
        }

        public List<Message> GetFiltered()
        {
            return FilterMessages;
        }

        public bool Register(string g_id, string nick, String password)
        {
            bool IsRegistered = false;
            /*if (isValidGroupID(g_id) & IsValidNickname(g_id, nick)==false)
            {
                
                User u = new User(nick, g_id);
                users.Add(u);
               // userHandler.AddUser(users);
                // IsRegistered = Login(g_id, nick);
                IsRegistered = true;
                log.Info("New User Regisered ");

            }*/
            IsRegistered = handler.Resgister(g_id, nick, password);
            return IsRegistered;
            
        }
        public void Logout()
        {
            LoggedinUser = null;
        }

        public String GetLoginUserID()
        {
            return this.LoggedinUser.getGroupID();
        }
        public String GetLoginUserName()
        {
            return this.LoggedinUser.getNick();
        }
        public Boolean MessagesContains(Message m)
        {
            bool contains = false;
            foreach(Message MM in messages)
            {
                if (MM.GetGuid().Equals(m.GetGuid()))
                {
                    contains = true;
                    break;
                }
            }
            return contains;
        }
        public Boolean FilterMessagesContains(Message m)
        {
            bool contains = false;
            foreach (Message MM in FilterMessages)
            {
                if (MM.GetGuid().Equals(m.GetGuid()))
                {
                    contains = true;
                    break;
                }
            }
            return contains;
        }

        public void SortByDateTime(Boolean Ascending)
        {
           
            if (Ascending)
            {
                SortedM = messages.OrderBy(x => x.GetDateTime()).ToList();
            }
            else
            {
               SortedM = messages.OrderByDescending<Message, DateTime>(x => x.GetDateTime()).ToList(); 
            }
            
        }
        public void SortByGroupID(Boolean Ascending)
        {
            if (Ascending)
            {
                SortedM = messages.OrderBy<Message, int>(message => message.GetUserGIDNumber()).ToList();
            }
            else
            {
               SortedM = messages.OrderByDescending<Message, int>(message => message.GetUserGIDNumber()).ToList();
            }
            
        }
        public void SortByUserName(Boolean Ascending)
        {
            if (Ascending)
            {
               SortedM = messages.OrderBy(x => x.GetUserName()).ToList();
            }
            else
            {
                SortedM = messages.OrderByDescending<Message, String>(message => message.GetUserName()).ToList();
            }
            
        }
        public void SortByAll(Boolean Ascending)
        {
            if (Ascending)
            {
                SortedM = messages.OrderBy<Message, int>(message => message.GetUserGIDNumber()).ThenBy<Message, String>(message => message.GetUserName()).ThenBy<Message, DateTime>(message => message.GetDateTime()).ToList();
            }
            else
            {
               SortedM = messages.OrderByDescending<Message, int>(message => message.GetUserGIDNumber()).ThenByDescending<Message, String>(message => message.GetUserName()).ThenByDescending<Message, DateTime>(message => message.GetDateTime()).ToList();
            }
            
        }
        
        public void SortFiltered(Boolean Ascending)
        {
            if (Ascending)
            {
                SortedMFilter = FilterMessages.OrderBy<Message, DateTime>(message => message.GetDateTime()).ToList();
            }
            else
            {
                SortedMFilter = FilterMessages.OrderByDescending<Message, DateTime>(message => message.GetDateTime()).ToList();
            }
            
        }
        public void SortFilteredAll(bool Ascending)
        {
            if (Ascending)
            {
                SortedMFilter = FilterMessages.OrderBy<Message, int>(message => message.GetUserGIDNumber()).ThenBy<Message, String>(message => message.GetUserName()).ThenBy<Message, DateTime>(message => message.GetDateTime()).ToList();
            }
            else
            {
                SortedMFilter = FilterMessages.OrderByDescending<Message, int>(message => message.GetUserGIDNumber()).ThenByDescending<Message, String>(message => message.GetUserName()).ThenByDescending<Message, DateTime>(message => message.GetDateTime()).ToList();
            }
        }

        public void SortFilteredUser(bool Ascending)
        {
            if (Ascending)
            {
                SortedMFilter = FilterMessages.OrderBy(x => x.GetUserName()).ToList();
            }
            else
            {
                SortedMFilter = FilterMessages.OrderByDescending<Message, String>(message => message.GetUserName()).ToList();
            }
        }

        public List<Message> getFilterMessages()
        {
            return FilterMessages;
        }

    }
}
