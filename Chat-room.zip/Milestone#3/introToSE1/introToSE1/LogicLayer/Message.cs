﻿using introToSE1.PersistantLayer;


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace introToSE.LogicLayer
{
    [Serializable()]
    public class Message : IComparable
    {
        const int MessLength_CONSTANT = 100;
        private String boody;
        private User user;
        private String guid;
        private DateTime date;
        
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Message()
        {

        }
        public Message(IMessage m)
        {
            boody = m.MessageContent;
            this.user = new User(m.UserName, m.GroupID);
            this.guid = m.guid;
            this.date = m.Date.ToLocalTime();
          
            log.Info("New message");
        }
        public Boolean CheckValidity(string msg)
        {
            Boolean validMsg = true;

            if (msg.Length > MessLength_CONSTANT) validMsg = false;

            return validMsg;
        }
        public String GetGuid()
        {
            return this.guid;
        }

        public DateTime GetDateTime()
        {
            return this.date;
        }

        public User getUser()
        {
            return this.user;
        }
        public String GetUserName()
        {
            return this.user.getNick();
        }
        public string GetUserGroupID()
        {
            return this.user.getGroupID();
        }
        public Boolean CanEdit(String newBody)
        {
            if (newBody.All(char.IsWhiteSpace))
            {
                return false;
            }
            if (CheckValidity(newBody))
            {
                this.boody = newBody;
                this.date = DateTime.Now;
                return true;
            }
            return false;
        }

        public String toString()
        {
            return this.user.getNick() + Environment.NewLine +
                   GetUserGroupID()+ Environment.NewLine +
                   this.boody + Environment.NewLine +
                   this.date;
        }

        public int CompareTo(object obj)
        {
            return date.CompareTo(((Message)obj).GetDateTime());
        }

        public int GetUserGIDNumber()
        {
            int i;
            try
            {
                i = int.Parse(this.GetUserGroupID());
                return i;
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            return 0;
             
        }
    }
}
