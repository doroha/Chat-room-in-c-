﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace introToSE.LogicLayer
{
    [Serializable()]
    public class User
    {
        private string nickName;
        private string groupId;
        private string password;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        public User(string nickName, string groupId, string password)
        {
            this.nickName = nickName;
            this.groupId = groupId;
            this.password = password;
        }
        public User(string nickName, string groupId)
        {
            this.nickName = nickName;
            this.groupId = groupId;
        }
        /*public Message Send(string msg, string url)
        {
            string s = (""+this.groupId+"");
            IMessage message = Communication.Instance.Send(url, s, this.nickName, msg);
            Message m = new Message(message);
            return m;
        }*/

        public String getNick()
        {
            return this.nickName;
        }

        public string getGroupID()
        {
            return this.groupId;
        }

        public User getUser()
        {
            return this;
        }

    }
}
