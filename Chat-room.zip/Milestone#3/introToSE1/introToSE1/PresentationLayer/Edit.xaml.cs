﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace introToSE1.PresentationLayer
{
    /// <summary>
    /// Interaction logic for Edit.xaml
    /// </summary>
    public partial class Edit : Window
    {
        ObservableGUI observableGUI { set; get; }
        public Edit(ObservableGUI observableGUI)
        {
            InitializeComponent();
            this.observableGUI = observableGUI;
            this.DataContext = observableGUI;
        }

        private void EditButt_Click(object sender, RoutedEventArgs e)
        {
            Boolean isEdit = observableGUI.Edit();
            if (isEdit)
            {
                BodyEdit.Text = "";
                observableGUI.EditMessageBody = "";
                observableGUI.OnPropertyChanged("EditMessageBody");
                observableGUI.SelectedMessage = null;
                observableGUI.OnPropertyChanged("SelectedMessage");
                this.Close();
            }
            else
            {
                MessageBox.Show("Was not able edit");
                BodyEdit.Text = "";
                observableGUI.EditMessageBody = "";
                observableGUI.OnPropertyChanged("EditMessageBody");
                this.Close();
            }
        }
    }
}
