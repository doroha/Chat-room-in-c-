﻿using introToSE.LogicLayer;

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace introToSE1.PresentationLayer
{
    /// <summary>
    /// Interaction logic for GUI.xaml
    /// </summary>
    public partial class GUI : Window
    {

        const int RetreiveMess_CONSTANT = 10;
        const int DisplayMess_CONSTANT = 20;
        const int MessMax_CONSTANT = 150;
        private static Timer timer;

        public GUI()
        {
            InitializeComponent();

            observableGUI = new ObservableGUI();
            this.DataContext = observableGUI;

        }

        private ObservableGUI observableGUI { set; get; }

        public bool Login(String GroupID, String UserName, String Password)
        {
            bool logedin = false;
            if (observableGUI.Login(GroupID, UserName, Password))
            {
                logedin = true;
                SetTimer();
                ChatView.ItemsSource = observableGUI.Messages;
                observableGUI.OnPropertyChanged("Messages");
                UnFilter.IsChecked = true;

            }
            //ChatView.ItemsSource = observableGUI.Messages;
            return logedin;


        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            observableGUI.Send();
        }

        public Boolean Register(String GroupID, String UserName, String Password)
        {///////add TimerSet to register

            bool IsRegis = observableGUI.Register(GroupID, UserName, Password);
            if (IsRegis)
            {
                Login(GroupID, UserName, Password);
            }
            else
            {
                MessageBox.Show("Was not able to Register");
            }
            return IsRegis;
        }

        private void Go_Click(object sender, RoutedEventArgs e)
        {
            observableGUI.Filtered = true;
            observableGUI.Go();

            ChatView.ItemsSource = observableGUI.FilteredMessages;

            observableGUI.OnPropertyChanged("FilteredMessages");
        }
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            observableGUI.Logout();
            timer.Close();
            WELCOME_ page = new WELCOME_();
            page.Show();
           // ObservableWelcome backPage = new ObservableWelcome();
            this.Close();

        }
        private void FilteredGroupID_TextChanged(object sender, TextChangedEventArgs e)
        {
            observableGUI.FilterGroupID = FilteredGroupID.Text;
        }

        private void FilteredUserName_TextChanged(object sender, TextChangedEventArgs e)
        {
            observableGUI.FilterUserName = FilteredUserName.Text;
        }

        private void ChatView_TextInput(object sender, TextCompositionEventArgs e)
        {
            ChatView.ItemsSource = observableGUI.Messages;

            observableGUI.Filtered = false;
        }

        private void MyMessageContent_TextChanged(object sender, TextChangedEventArgs e)
        {
            observableGUI.MessageContent = MyMessageContent.Text;
            observableGUI.OnPropertyChanged("MessageContent");
        }

        private void UnFilterBox_Checked(object sender, RoutedEventArgs e)
        {
            ChatView.ItemsSource = observableGUI.Messages;
            observableGUI.Filtered = false;
            observableGUI.FilterGroupID = "";
            observableGUI.OnPropertyChanged("FilterGroupID");
            observableGUI.FilterUserName = "";
            observableGUI.OnPropertyChanged("FilterUserName");
            observableGUI.FilteredMessages.Clear();
            observableGUI.OnPropertyChanged("FilteredMessages");




        }

        private void DateTime_Click(object sender, RoutedEventArgs e)
        {
            if (sender == DateTime)
            {
                DateTime.IsChecked = true;
                UserGroupID.IsChecked = false;
                UserName.IsChecked = false;
                All.IsChecked = false;
                observableGUI.SortBy = 0;
            }
            else
            {
                if (sender == UserGroupID)
                {
                    DateTime.IsChecked = false;
                    UserGroupID.IsChecked = true;
                    UserName.IsChecked = false;
                    All.IsChecked = false;
                    observableGUI.SortBy = 1;
                }
                else
                {
                    if (sender == UserName)
                    {
                        DateTime.IsChecked = false;
                        UserGroupID.IsChecked = false;
                        UserName.IsChecked = true;
                        All.IsChecked = false;
                        observableGUI.SortBy = 2;

                    }
                    else
                    {
                        DateTime.IsChecked = false;
                        UserGroupID.IsChecked = true;
                        UserName.IsChecked = false;
                        All.IsChecked = true;
                        observableGUI.SortBy = 3;
                    }
                }
            }
            observableGUI.OnPropertyChanged("SortBy");
        }

        private void Descending_Click(object sender, RoutedEventArgs e)
        {
            if (sender == Ascendinding)
            {
                Ascendinding.IsChecked = true;
                observableGUI.Ascending = true;
                observableGUI.OnPropertyChanged("Ascending");

                Descending.IsChecked = false;
                observableGUI.Descending = false;
                observableGUI.OnPropertyChanged("Descending");

            }
            else
            {
                Ascendinding.IsChecked = false;
                observableGUI.Ascending = false;
                observableGUI.OnPropertyChanged("Ascending");
                Descending.IsChecked = true;
                observableGUI.Descending = true;
                observableGUI.OnPropertyChanged("Descending");
            }
        }
        private void SetTimer()
        {
            timer = new Timer(2000);
            timer.Elapsed += OnTimedEvent;
            timer.AutoReset = true;
            timer.Enabled = true;
        }
        private void OnTimedEvent(object sender, ElapsedEventArgs e)
        {

            observableGUI.FromMessageToString();
        }

        //      private void ChatView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //      {
        //          observableGUI.EditClick();
        //      }

        private void ChatView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int i = ChatView.SelectedIndex;
            if (i != (-1))
            {
                observableGUI.EditClick(i);
            }
        }
    }
}
    
