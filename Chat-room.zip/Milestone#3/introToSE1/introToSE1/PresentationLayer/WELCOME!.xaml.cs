﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace introToSE1.PresentationLayer
{
    /// <summary>
    /// Interaction logic for WELCOME_.xaml
    /// </summary>
    public partial class WELCOME_ : Window
    {

        public String HashedPassword = "";
        public Boolean CorrectPassword = true;
        String salt = "1337";


        public WELCOME_()
        {
            InitializeComponent();
            observable = new ObservableWelcome();
            DataContext = observable;
            gui = new GUI();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            bool IsLogedin = false;
            try
            {
                IsLogedin = gui.Login(observable.GroupID, observable.UserName, this.HashedPassword);
                if (IsLogedin)
                {
                    this.Close();
                    gui.Show();
                }
                else
                {
                    MessageBox.Show("Was not able to Login");
                }
                
            }
            catch(Exception d)
            {
                MessageBox.Show(d.ToString());
            }
                
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            bool isRegis = gui.Register(observable.GroupID, observable.UserName, this.HashedPassword);
            if (isRegis)
            {
                //gui.Register(observable.GroupID, observable.UserName, this.HashedPassword);
                gui.Show();
                this.Close();
            }
        }
        public GUI gui { set; get; }
        private ObservableWelcome observable { set; get; }

        private void UserNameText_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
      {
            PasswordBox pb = sender as PasswordBox;

            if (pb.Password.Length >= 4)
            {


                if (!(pb.Password.Length >= 4 && pb.Password.Length <= 16))
                {
                    CorrectPassword = false;
                    MessageBox.Show("The Password you inserted is not in correct length ", "Invalid password");

                    //   pb.Password = "";
                }

                if (pb.Password[0] == 13 || pb.Password.Contains(' ') || pb.Password.Equals(""))
                {
                    CorrectPassword = false;
                    MessageBox.Show("Spaces,Inter Key, or empty password are not allowes", "Invalid password");
                }

                for (int i = 0; i < pb.Password.Length; i++)

                {
                    //if (!(pb.Password[i] >= 48 && pb.Password[i] <= 57) || !(pb.Password[i] >= 65 && pb.Password[i] <= 90) || !(pb.Password[i] >= 97 && pb.Password[i] <= 122))
                    if(!Char.IsLetterOrDigit(pb.Password[i]))
                    {
                        CorrectPassword = false;
                        MessageBox.Show("The password should contain only lowercase or upper case letters and numbers", "Invalid password");
                    }
                }

                if (CorrectPassword)
                {
                    this.HashedPassword = introToSE.LogicLayer.hashing.GetHashString(pb.Password + salt);

                }
            }
        }
    }


}

  
