﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace introToSE1.PresentationLayer
{
    class ObservableWelcome : INotifyPropertyChanged
    {
        
        public event PropertyChangedEventHandler PropertyChanged;

        public ObservableWelcome()
        {
            
        }

        private string userName = "";
        public string UserName
        {
            get
            {
                return userName;
            }
            set
            {
                userName = value;
                OnPropertyChanged("UserName");
            }
        }
        private string groupID = "";
        public string GroupID
        {
            get
            {
                return groupID;
            }
            set
            {
                groupID = value;
                OnPropertyChanged("GroupID");
            }
        }
        private string password = "";
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
                OnPropertyChanged("Password");
            }
        }

        #region Binding
        private float sliderOneWay = 0.0f;
        public float SliderOneWay
        {
            get
            {
                return sliderOneWay;
            }
            set
            {
                if (value >= 0.0 && value <= 100.0)
                {
                    sliderOneWay = value;
                    OnPropertyChanged("SliderOneWay");
                }
            }
        }
        private float sliderOneWayToSource = 0.0f;
        public float SliderOneWayToSource
        {
            get
            {
                return sliderOneWayToSource;
            }
            set
            {
                if (value >= 0.0 && value <= 100.0)
                {
                    sliderOneWayToSource = value;
                    OnPropertyChanged("SliderOneWayToSource");
                }
            }
        }
        private float sliderTwoWay = 0.0f;
        public float SliderTwoWay
        {
            get
            {
                return sliderTwoWay;
            }
            set
            {
                if (value >= 0.0 && value <= 100.0)
                {
                    sliderTwoWay = value;
                    OnPropertyChanged("SliderTwoWay");
                }
            }
        }

        #endregion

        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}

