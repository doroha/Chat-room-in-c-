﻿using introToSE.LogicLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;



namespace introToSE1.PresentationLayer
{

    public class ObservableGUI : INotifyPropertyChanged
        {
        public event PropertyChangedEventHandler PropertyChanged;
        private Chatroom chatroom { set; get; }
        
        public ObservableCollection<String> Messages { get; } = new ObservableCollection<String>();
          
        private List<Message> _CRmessages = new List<Message>();

        public List<Message> CRMessages
        {
            get { return _CRmessages; }
            set
            {
                _CRmessages = value;
                OnPropertyChanged("CRMessages");
            }
        }
      //  public ObservableCollection<String> MMM = new ObservableCollection<string>();
        public ObservableCollection<String> FilteredMessages { set; get; } = new ObservableCollection<string>();
        //private LinkedList<Message> mess { set; get; }
       
        private void FilteredMessages_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged("FilteredMessages");
        }

        private string messageContent = "";
            public string MessageContent
            {
                get
                {
                    return messageContent;
                }
                set
                {
                    messageContent = value;
                    OnPropertyChanged("MessageContent");
                }
            }
        public Boolean Filtered { set; get; }
   //     public Message SelectedMessage { set; get; }
        private string filteruserName = "";
        public string FilterUserName
        {
            get
            {
                return filteruserName;
            }
            set
            {
                filteruserName = value;
                OnPropertyChanged("FilterUserName");
            }
        }

        private Message selectedMessage = null;
        public Message SelectedMessage
        {
            get
            {
                return selectedMessage;
            }
            set
            {
                selectedMessage = value;
                OnPropertyChanged("SelectedMessage");
            }
        }

        private string editGroupID = "";
        public string EditGroupID
        {
            get
            {
                return editGroupID;
            }
            set
            {
                editGroupID = value;
                OnPropertyChanged("EditGroupID");
            }
        }

        private string editUserName = "";
        public string EditUserName
        {
            get
            {
                return editUserName;
            }
            set
            {
                editUserName = value;
                OnPropertyChanged("EditUserName");
            }
        }

        private string editMessageBody = "";
        public string EditMessageBody
        {
            get
            {
                return editMessageBody;
            }
            set
            {
                editMessageBody = value;
                OnPropertyChanged("EditMessageBody");
            }
        }

        private string filtergroupID = "";
        public string FilterGroupID
        {
            get
            {
                return filtergroupID;
            }
            set
            {
                filtergroupID = value;
                OnPropertyChanged("FilterGroupID");
            }
        }
        private Boolean ascending = true;
        public Boolean Ascending
        {
            get
            {
                return ascending;
            }
            set
            {
                ascending = value;
                FromMessageToString();
                OnPropertyChanged("Messages");
                OnPropertyChanged("Ascending");
            }
        }

        private Boolean descending = false;
        public Boolean Descending
        {
            get
            {
                return descending;
            }
            set
            {
                descending = value;
                FromMessageToString();
                
                OnPropertyChanged("Descending");
                OnPropertyChanged("Messages");
            }
        }
        
        private int sortBy = 0;
        public int SortBy
        {
            get
            {
                return sortBy;
            }
            set
            {
                sortBy = value;
                FromMessageToString();
                OnPropertyChanged("Messages");
                OnPropertyChanged("SortBy");
            }
        }
        public void FromMessageToString()
        {
            CRMessages = chatroom.RetreiveLast(sortBy,ascending);
            
         
            App.Current.Dispatcher.Invoke((Action)delegate
            {
                Messages.Clear();
                OnPropertyChanged("Messages");
                
            });
           App.Current.Dispatcher.Invoke((Action)delegate
            {
               foreach(Message m in CRMessages)
                {
                    Messages.Add(m.toString());
                    if (Filtered)
                    {
                        Go();
                    }
                }
            });
           
            OnPropertyChanged("Messages");
          //  CRMessages.Clear();
        } 
        
        public Boolean Edit()
        {
            return chatroom.EditMessage(SelectedMessage, EditMessageBody);
        }
       
        
        public void Send()
        {
            Boolean IsMessOK = true;
            if (MessageContent.All(char.IsWhiteSpace))
            {
                IsMessOK = false;
            }
            if (IsMessOK)
            {
                chatroom.Send(MessageContent);
                MessageContent = "";
                OnPropertyChanged("MessageContent");
                FromMessageToString();
                OnPropertyChanged("Messages");
            }
            else
            {
                MessageBox.Show("Your message is invalid");
            }
        }
        public void Go()
        {
            if (IsAllNumbers(FilterGroupID) & FilterUserName.Equals("") & Filtered)
            {
                List<Message> tmp = chatroom.DisplayAllFilterGroupID(FilterGroupID, Ascending, sortBy);
                if (tmp.Count > 0)
                {
                    FilteredMessages.Clear();
                    OnPropertyChanged("FilterMessages");
                    foreach (Message m in tmp)
                    {
                        FilteredMessages.Add(m.toString());
                    }
                    OnPropertyChanged("FilterMessages");
                }
                else
                {
                    Filtered = false;
                    MessageBox.Show("Group ID is invalid");
                }
            }
            else if (IsAllNumbers(FilterGroupID) & FilterUserName != null & Filtered)
            {
                List<Message> tmp = chatroom.DisplayAll(FilterGroupID, FilterUserName, Ascending);
                if (tmp.Count > 0)
                {
                    FilteredMessages.Clear();
                    OnPropertyChanged("FilterMessages");
                    foreach (Message m in tmp)
                    {
                        FilteredMessages.Add(m.toString());
                    }
                    OnPropertyChanged("FilterMessages");
                }
                else
                {
                    Filtered = false;
                    MessageBox.Show("User was not found");
                }
            }
            else
            {
                Filtered = false;
                MessageBox.Show("Group ID or User Name is invalid");
            }
            
        }
        public bool Login(String GroupID, String UserName, String password)
        {
            return (chatroom.Login(GroupID, UserName,password));
          
        }
        public Boolean IsAllNumbers(String str)
        {
            Boolean output = false;
            try
            {
                if (str.All(char.IsDigit))
                {
                    output = true;
                }
                return output;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            return output;

        }
        public bool Register(String GroupID, String UserName, String password)
        {
            Boolean valid = (chatroom.isValidGroupID(GroupID) & IsAllNumbers(GroupID));
            Boolean ValidNN = true;
            Boolean IsRegis = false;
            if (valid)
            {
                ValidNN = chatroom.IsValidNickname(GroupID, UserName);
                if (ValidNN)
                {
                   IsRegis = chatroom.Register(GroupID, UserName, password);
                  
                }
                else
                {
                    MessageBox.Show("nickname is already in use, try again");
                }
            }
            else
            {
                MessageBox.Show("groupID is invalid, please try again.");
            }
            return IsRegis;
        }
        public void Logout()
        {
            chatroom.Logout();
        }

        public void EditClick(int i)
        {
            if (!Filtered) {
                SelectedMessage = CRMessages[i];
                if (chatroom.MessageFromUser(selectedMessage))
                {
                    this.EditGroupID = chatroom.GetLoginUserID();
                    this.EditUserName = chatroom.GetLoginUserName();
                    Edit edit = new Edit(this);
                    edit.Show();
                }
                else
                {
                    selectedMessage = null;
                    return;
                }
            }
            else
            {
                SelectedMessage = chatroom.getFilterMessages()[i];
                if (chatroom.MessageFromUser(selectedMessage))
                {
                    this.EditGroupID = chatroom.GetLoginUserID();
                    this.EditUserName = chatroom.GetLoginUserName();
                    Edit edit = new Edit(this);
                    edit.Show();
                }
                else
                {
                    selectedMessage = null;
                    return;
                }
            }
        }
       



        #region Binding
        private float sliderOneWay = 0.0f;
            public float SliderOneWay
            {
                get
                {
                    return sliderOneWay;
                }
                set
                {
                    if (value >= 0.0 && value <= 100.0)
                    {
                        sliderOneWay = value;
                        OnPropertyChanged("SliderOneWay");
                    }
                }
            }
            private float sliderOneWayToSource = 0.0f;
            public float SliderOneWayToSource
            {
                get
                {
                    return sliderOneWayToSource;
                }
                set
                {
                    if (value >= 0.0 && value <= 100.0)
                    {
                        sliderOneWayToSource = value;
                        OnPropertyChanged("SliderOneWayToSource");
                    }
                }
            }
            private float sliderTwoWay = 0.0f;
            public float SliderTwoWay
            {
                get
                {
                    return sliderTwoWay;
                }
                set
                {
                    if (value >= 0.0 && value <= 100.0)
                    {
                        sliderTwoWay = value;
                        OnPropertyChanged("SliderTwoWay");
                    }
                }
            }

            #endregion

            public void OnPropertyChanged([CallerMemberName] string propertyName = null)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }


        public ObservableGUI()
        {
            Messages.CollectionChanged += Messages_CollectionChanged;
           // FilteredMessages.CollectionChanged += FilteredMessages_CollectionChanged;
            chatroom = new Chatroom();
            
            
        }
        private void Messages_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged("Messages");
        }
    }
    }


