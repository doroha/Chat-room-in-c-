﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using introToSE.LogicLayer;
using introToSE1.PresentationLayer;
using NUnit.Framework;

namespace TestProject
{
    [TestFixture]
    class UnitTest4
    {
        introToSE1.PresentationLayer.ObservableGUI g;
        [Test]
        public void SendingBlankMessage_ThrowException()
        {
            g = new ObservableGUI();
            g.MessageContent = "   ";
            g.Send();
            Assert.AreEqual("   ", g.MessageContent);
        }
    }
}

