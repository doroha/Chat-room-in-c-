﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using introToSE.LogicLayer;
using introToSE1.PresentationLayer;
using NUnit.Framework;

namespace TestProject
{
    [TestFixture]
    class UnitTest3
    {
        introToSE1.PresentationLayer.ObservableGUI g;
        [Test]
        public void isValidGroupIDTest()
        {
            g = new ObservableGUI();
            string nick = "noaaaaaa";
            string g_id = "haha";
            Boolean result = g.Register(g_id,nick);
            Assert.IsFalse(result);
        }
    }
}

