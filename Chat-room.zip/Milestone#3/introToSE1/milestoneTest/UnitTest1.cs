﻿using System;
using NUnit.Framework;
using introToSE.LogicLayer;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MileStoneClient.CommunicationLayer;


namespace UnitTestProject3
{
    [TestFixture]
    public class UnitTest1
    {

        introToSE.LogicLayer.Message c;
        [Test]

        public void CheckValidityTest()
        {
            c = new introToSE.LogicLayer.Message();
            String check = "helloChat";
            for (int i = 0; i < 20; i++)
            {
                check = check + check;
            }
            bool result = c.CheckValidity(check);
            Assert.IsFalse(result);
        }
    }
}
