﻿using System;
using NUnit.Framework;
using introToSE.LogicLayer;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    [TestFixture]
    public class UnitTest2
    {
        introToSE.LogicLayer.Chatroom c; //i dont know why the chatroom class did not read from the logic layer // 

        [Test]
        public void isValidNicknameTest_ResultIsFalse()
        {
            c = new introToSE.LogicLayer.Chatroom();

            string nick = "noa";
            string g_id = "20";     //nick name dor in group 28// 

            bool result = c.IsValidNickname(g_id, nick);
            Assert.IsFalse(result);
        }
    }
}

