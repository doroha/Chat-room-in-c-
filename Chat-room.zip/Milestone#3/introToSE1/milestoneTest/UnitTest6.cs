﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using introToSE.LogicLayer;
using NUnit.Framework;

namespace TestProject
{
    [TestFixture]
    class UnitTest6
    {
        introToSE.LogicLayer.User dor;
        string nickname;
        string g_id;
        [Test]
        public void GroupIDCheck_ShouldBeEqual()
        {
            nickname = "dor";
            g_id = "28";

            dor = new User(nickname, "28");

            Assert.AreEqual(dor.getGroupID(), g_id);
        }
    }
}


