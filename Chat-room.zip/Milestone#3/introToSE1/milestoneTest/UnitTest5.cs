﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using introToSE.LogicLayer;
using NUnit.Framework;

namespace TestProject
{
    [TestFixture]
    class UnitTest5
    {
        introToSE.LogicLayer.Message m1;
        introToSE.LogicLayer.Message m2;
        [Test]
        public void CompareToTest()
        {
            m1 = new introToSE.LogicLayer.Message();
            m2 = m1;

            int compare = m1.CompareTo(m2);

            Assert.AreEqual(0, compare);
        }
    }
}

